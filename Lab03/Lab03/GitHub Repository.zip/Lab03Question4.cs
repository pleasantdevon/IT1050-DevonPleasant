﻿using System;

namespace Lab03_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int isTrue = 522;

            if (isTrue <= 50)
            {
                Console.WriteLine("It is True!");
            }
          else
        {
                Console.WriteLine("It is False!");
        }
            Console.ReadLine();
        }
    }
}
