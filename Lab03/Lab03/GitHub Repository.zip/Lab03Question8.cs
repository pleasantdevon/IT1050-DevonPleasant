﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab03_8
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 10;

            while (x <= 20)
            {
                Console.WriteLine(x);
                x += 2;
 
            }
            Console.ReadLine();
            
        }
    }
}
